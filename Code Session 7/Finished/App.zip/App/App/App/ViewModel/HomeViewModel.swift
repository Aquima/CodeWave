//
//  HomeViewModel.swift
//  App
//
//  Created by Raul on 21/12/21.
//

import Foundation
protocol HomeViewModelDelegate: AnyObject {
    func show(amount: String)
}
class HomeViewModel: NSObject, ShowBalanceAccountViewDelegate {
    var account: Account!
    var increment: Double!
    weak var delegate: HomeViewModelDelegate?
    
    override init() {
        account = Account()
    }
    func didSelectOperate(type: TypeField) {
        account.increment(self.increment, currency: "$")
        self.delegate?.show(amount: account.currentMoney())
    }
    func incrementValue(value: Double) {
        self.increment = value
    }
}
