//
//  AppDelegate.swift
//  App
//
//  Created by Raul Quispe on 15/12/21.
//

import UIKit
import IQKeyboardManagerSwift
@main
class AppDelegate: UIResponder, UIApplicationDelegate {


    var windows:UIWindow!
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        IQKeyboardManager.shared.enable = true
        windows = UIWindow(frame: UIScreen.main.bounds)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let view = storyboard.instantiateViewController(withIdentifier: "homeBankingView")
 
        windows.rootViewController = view
        windows.makeKeyAndVisible()
        return true
    }
    //appmeli://?code=456465
    func application(_ app: UIApplication, open url: URL, options: [UIApplication.OpenURLOptionsKey : Any] = [:]) -> Bool {
           let urlComponents = URLComponents(url: url, resolvingAgainstBaseURL: false)
           let items = (urlComponents?.queryItems)! as [NSURLQueryItem]
           if (url.scheme == "appmeli") {
               if let _ = items.first, let propertyName = items.first?.name, let propertyValue = items.first?.value {
                   print(propertyValue)
                  }
           }
           return false
      }

}

