//
//  AppTests.swift
//  AppTests
//
//  Created by Raul Quispe on 15/12/21.
//

import XCTest
@testable import App

class AppTests: XCTestCase {
    var  account: Account!
    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        account = Account()
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }
    func testAccountWithBalanceZero() {
        XCTAssertTrue(account.balance == 0.0)
    }
    func testAccountIncrementBalance() {
        let amount = 10.00
        account.increment(amount,currency: "$")
        XCTAssertTrue(account.balance == 10.00)
    }
    func testCurrentBalance() {
        XCTAssertTrue(account.currentBalance() == 0.0)
    }
    func testChangeCurrency() {
        let amount = 10.00
        account.increment(amount,currency: "$")
        XCTAssertTrue(account.change(currency: "€") == "€")
    }
    func testCurrentCurrency() {
        let amount = 10.00
        account.increment(amount,currency: "$")
        XCTAssertTrue(account.currency == "$")
        XCTAssertTrue(account.change(currency: "€") == "€")
        XCTAssertTrue(account.currency == "€")
    }
    func testWithdrawWithoutBalance() {
        let amount = 20.00
        XCTAssertTrue(try account.withdraw(amount) == .notBalance)
    }
    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

}
