//
//  ShowBalanceAccountView.swift
//  App
//
//  Created by Raul on 16/12/21.
//

import UIKit
protocol ShowBalanceAccountViewDelegate: AnyObject {
    func didSelectOperate(type: TypeField)
}
class ShowBalanceAccountView: UIView {
    weak var delegate: ShowBalanceAccountViewDelegate?
    var account: Account!
    @IBOutlet weak var lblCurrentBalance: UILabel!
    
    @IBOutlet var inputs: [UITextField]!
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    func showBalance(_ account: Account) {
        self.account = account
        lblCurrentBalance.text = account.currentMoney()
    }

    @IBAction func tapToOperation(_ sender: Any) {
        let field = inputs.first!
        let typeField = TypeField(rawValue: field.tag)
        if typeField == .increment {
            let amount = Double(field.text!)
            self.account.increment(amount!, currency: "$")
            lblCurrentBalance.text = account.currentMoney()
            self.delegate?.didSelectOperate(type: typeField!)
        }
    }
}
