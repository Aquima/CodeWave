//
//  HomeBankingViewController.swift
//  App
//
//  Created by Raul on 16/12/21.
//

import UIKit
import LocalAuth
import Alamofire
class HomeBankingViewController: UIViewController {
    
    @IBOutlet var showBalanceView: ShowBalanceAccountView!
    override func viewDidLoad() {
        super.viewDidLoad()
        let account = Account()
        guard let showBalanceAccountView = self.view as? ShowBalanceAccountView else {
            return
        }
        showBalanceAccountView.showBalance(account)
        let currentUser = User(name: "Raul")
        let customColor = CustomColors.green
        self.view.backgroundColor = customColor.color
        print(customColor.describeColor())
        showBalanceView.delegate = self
        let localAuth = LocalAuth()
        localAuth.initializeAuth()
        let url = "https://41285dcf-df2d-4747-8b0d-b6ee1a0c340a.mock.pstmn.io/stackExchange"
        AF.request(url).responseDecodable(of: MoneyExchange.self, completionHandler: { response in
            if response.error == nil {
                guard let stackExchange = response.value else {
                    return
                }
                print(stackExchange.count)
            }
        })
//        let urlrequest = URL.init(string: url)
    }
}
// MARK: ShowBalanceAccountViewDelegate
extension HomeBankingViewController:
    ShowBalanceAccountViewDelegate {
    func didSelectOperate(type: TypeField) {
        print(type)
    }
}
