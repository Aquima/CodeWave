//
//  TypeField.swift
//  App
//
//  Created by Raul on 16/12/21.
//

import Foundation

enum TypeField: Int {
    case increment = 0
    case withdraw = 1
}
