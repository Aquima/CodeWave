# LocalAuth

[![CI Status](https://img.shields.io/travis/aquima/LocalAuth.svg?style=flat)](https://travis-ci.org/aquima/LocalAuth)
[![Version](https://img.shields.io/cocoapods/v/LocalAuth.svg?style=flat)](https://cocoapods.org/pods/LocalAuth)
[![License](https://img.shields.io/cocoapods/l/LocalAuth.svg?style=flat)](https://cocoapods.org/pods/LocalAuth)
[![Platform](https://img.shields.io/cocoapods/p/LocalAuth.svg?style=flat)](https://cocoapods.org/pods/LocalAuth)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

LocalAuth is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'LocalAuth'
```

## Author

aquima, raul.quispe@live.com

## License

LocalAuth is available under the MIT license. See the LICENSE file for more info.
