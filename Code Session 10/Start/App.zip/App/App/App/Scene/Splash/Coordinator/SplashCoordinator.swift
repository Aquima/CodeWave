//
//  SplashCoordinator.swift
//  App
//
//  Created by Raul on 21/12/21.
//

import UIKit

class SplashCoordinator: Coordinator {
    var navigation: UINavigationController
    init(navigation: UINavigationController) {
        self.navigation = navigation
    }
    func start() {
        let vc = SplashViewController()
        vc.delegate = self
        self.navigation.pushViewController(vc, animated: true)
    }
}
extension SplashCoordinator: SplashViewControllerDelegate {
    func goToHomeView(with amount: String) {
        let homeCoordinator: HomeCoordinator = HomeCoordinator(navigation: self.navigation, amount: amount)
        homeCoordinator.start()
    }
}
