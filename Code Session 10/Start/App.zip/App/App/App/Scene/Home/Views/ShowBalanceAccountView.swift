//
//  ShowBalanceAccountView.swift
//  App
//
//  Created by Raul on 16/12/21.
//

import UIKit
protocol ShowBalanceAccountViewDelegate: AnyObject {
    func didSelectOperate(type: TypeField)
    func incrementValue(value: Double)
}
class ShowBalanceAccountView: UIView {
    weak var delegate: ShowBalanceAccountViewDelegate?
   
    @IBOutlet weak var lblCurrentBalance: UILabel!
    
    @IBOutlet var inputs: [UITextField]!

    func setupUI(){
        let increment = inputs.first!
        increment.addTarget(self, action: #selector(didChangeField(texfield:)), for: .editingChanged)
    }
    @objc func didChangeField(texfield: UITextField){
        if let increment = Double(texfield.text!) {
            self.delegate?.incrementValue(value: increment)
        }
    }
    func showBalance(_ account: Account) {
//        self.account = account
//        lblCurrentBalance.text = account.currentMoney()
    }

    @IBAction func tapToOperation(_ sender: Any) {
        let field = inputs.first!
        let typeField = TypeField(rawValue: field.tag)
        self.delegate?.didSelectOperate(type: typeField!)

//        if typeField == .increment {
//            let amount = Double(field.text!)
//            self.account.increment(amount!, currency: "$")
//            lblCurrentBalance.text = account.currentMoney()
//            self.delegate?.didSelectOperate(type: typeField!)
//        }
    }
}
