//
//  CustomColors.swift
//  App
//
//  Created by Raul on 17/12/21.
//

import Foundation
import UIKit
protocol CustomColorsProtocol {
    func describeColor() -> String
}

enum CustomColors: CustomColorsProtocol {
    case red
    case green
    //Properties
    var color: UIColor {
        switch self {
        case .red:
            return #colorLiteral(red: 0.971568644, green: 0.2421498299, blue: 0.0771696642, alpha: 1)
        case .green:
            return #colorLiteral(red: 0.2035443485, green: 0.4148853421, blue: 0.08765400201, alpha: 1)
        }
    }
    func describeColor() -> String {
        var description: String!
        switch self {
        case .red:
            description = "Primary Red"
        case .green:
            description = "Prymary Green"
        }
        return description
    }
}
