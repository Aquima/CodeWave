//
//  Coordinator.swift
//  App
//
//  Created by Raul on 21/12/21.
//

import Foundation
import UIKit
/*
  Para navegacion cargar la vista y tambien para recibir los parametros desde otras vistas, saber con que vistas interactua esa vista
 */
protocol Coordinator {
    var navigation: UINavigationController {get}
    func start()
}
