//
//  SplashViewController.swift
//  App
//
//  Created by Raul on 21/12/21.
//

import UIKit

protocol SplashViewControllerDelegate: AnyObject {
    func goToHomeView(with amount: String)
}
class SplashViewController: UIViewController {
    var delegate: SplashViewControllerDelegate?
    var label: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.view.backgroundColor = .orange
        setupUI()
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                //call any function
            self.delegate?.goToHomeView(with: "400.0")
         }
        
    }
    func setupUI(){
        label = UILabel()
        self.view.addSubview(label)
        
        label.text = "Splash"
        label.frame = CGRect(x: 100, y: 100, width: 200, height: 20)
        label.textColor = .white
    }
    override func viewWillAppear(_ animated: Bool) {
        print("viewWillAppear Splash")
    }
    override func viewDidAppear(_ animated: Bool) {
        print("Aparece Splash")
        
        if let value = UserDefaults.standard.object(forKey: "sp") as? String {
            UserDefaults.standard.removeObject(forKey: "sp")
            label.text = value
        }
        //RepositoryPattern: WorkerPattern, Networking, Interceptor, etc
        //Storage Local: UserDefault, Keychain, CoreData, FileSystem, Library Audio y Photo
        //Storage Remote: APIRest, GraphQL, FacebookSDK, etc
    }
    override func viewWillDisappear(_ animated: Bool) {
        print("viewWillDisappear Splash")
    }
    override func viewDidDisappear(_ animated: Bool) {
        print("Desaparece Splash")
    }
   

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
