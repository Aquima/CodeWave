//
//  MoneyExchange.swift
//  App
//
//  Created by Raul on 17/12/21.
//

import Foundation

// MARK: - MoneyExchangeElement
struct MoneyExchangeElement: Codable {
    let typeMoney: String
    let rate: Double
}
//Grand Central Dispatch
typealias MoneyExchange = [MoneyExchangeElement]
