//
//  HomeBankingViewController.swift
//  App
//
//  Created by Raul on 16/12/21.
//

import UIKit
import LocalAuth
import Alamofire
protocol HomeBankingViewControllerDelegate: AnyObject {
    func goToSetting()
}
class HomeBankingViewController: UIViewController,
                                 HomeViewModelDelegate {
    var amount: String!
    var delegate: HomeBankingViewControllerDelegate?
    var viewModel: HomeViewModel!
    @IBOutlet var showBalanceView: ShowBalanceAccountView!
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel = HomeViewModel()
        viewModel.delegate = self
        showBalanceView.delegate = viewModel
        setupUI()
    }
    override func viewDidAppear(_ animated: Bool) {
        print("Aparece Home")
    }
    override func viewDidDisappear(_ animated: Bool) {
        print("Desaparece Home")
    }
    @IBAction func goToSettings(_ sender: Any) {
//        let userDefault = UserDefaults.standard
//        userDefault.set("SSaved", forKey: "sp")
//        userDefault.synchronize()
//        self.navigationController?.popViewController(animated: true)
        self.delegate?.goToSetting()
    }
    func setupUI(){
        
        showBalanceView.setupUI()
        
        showBalanceView.lblCurrentBalance.text = amount
//        let account = Account()
//        guard let showBalanceAccountView = self.view as? ShowBalanceAccountView else {
//            return
//        }
//        showBalanceAccountView.showBalance(account)
//        let currentUser = User(name: "Raul")
//        let customColor = CustomColors.green
//        self.view.backgroundColor = customColor.color
//        print(customColor.describeColor())
//
//        
//        let localAuth = LocalAuth()
//        localAuth.initializeAuth()
//        let url = "https://41285dcf-df2d-4747-8b0d-b6ee1a0c340a.mock.pstmn.io/stackExchange"
//        AF.request(url).responseDecodable(of: MoneyExchange.self, completionHandler: { response in
//            if response.error == nil {
//                guard let stackExchange = response.value else {
//                    return
//                }
//                print(stackExchange.count)
//            }
//        })
    }
    // MARK:
    func show(amount: String) {
        showBalanceView.lblCurrentBalance.text = amount
    }
}

