//
//  HomeCoordinator.swift
//  App
//
//  Created by Raul on 21/12/21.
//

import UIKit

class HomeCoordinator: Coordinator {
    var navigation: UINavigationController
    private var amount: String!
    init(navigation: UINavigationController,
         amount: String) {
        self.navigation = navigation
        self.amount = amount
    }
    func start() {
        //Storyboard
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let vc: HomeBankingViewController = storyboard.instantiateViewController(withIdentifier: "homeBankingView") as? HomeBankingViewController {
            vc.amount = self.amount
            vc.delegate = self

            self.navigation.pushViewController(vc, animated: true)
        }
       
    }
}
extension HomeCoordinator: HomeBankingViewControllerDelegate {
    func goToSetting() {
        let settingsCoordinator = SettingsCoordinator(navigation: self.navigation)
        settingsCoordinator.start()
    }
}
