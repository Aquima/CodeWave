//
//  CategoryTableViewCell.swift
//  App
//
//  Created by Raul on 23/12/21.
//

import UIKit

class CategoryTableViewCell: UITableViewCell {
   
    
    static let identifier: String = "CategoryTableViewCell"
    static let heigtSize = 80.0
    
    var categoryOptionView = CategoryOptionView()
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: .default, reuseIdentifier: CategoryTableViewCell.identifier)
        createOptionView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
       
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func load(title:String){
        self.textLabel?.text = title
        self.textLabel?.textColor = .white
        self.contentView.backgroundColor = .blue
    }
    func createOptionView() {
        self.contentView.addSubview(categoryOptionView)
        categoryOptionView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            categoryOptionView.leadingAnchor.constraint(equalTo: self.contentView.leadingAnchor),
            categoryOptionView.trailingAnchor.constraint(equalTo: self.contentView.trailingAnchor, constant: 0),
            categoryOptionView.topAnchor.constraint(equalTo: self.contentView.topAnchor),
            categoryOptionView.bottomAnchor.constraint(equalTo: self.contentView.bottomAnchor)
            ])
        categoryOptionView.createOption()
    }
   
}
