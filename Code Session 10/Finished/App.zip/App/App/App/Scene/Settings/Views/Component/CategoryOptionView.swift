//
//  CategoryOptionView.swift
//  App
//
//  Created by Raul on 23/12/21.
//

import UIKit

class CategoryOptionView: UIView, UICollectionViewDelegate, UICollectionViewDataSource {
    private var collectionView: UICollectionView!
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 6
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let collectionCell = collectionView.dequeueReusableCell(withReuseIdentifier: OptionCollectionViewCell.identifier, for: indexPath) as? OptionCollectionViewCell
        collectionCell?.contentView.backgroundColor = .white
//        collectionCell?.createCircle()
        return collectionCell!
    }
    func createOption(){
//        for index in 0...2 {
//            let view = UIView.init(frame: CGRect(x: (index)*60 + (index)*10, y: 10, width: 60, height: 60))
//            view.backgroundColor = .white
//            self.contentView.addSubview(view)
//        }
        let flowLayout = UICollectionViewFlowLayout()
        // Now setup the flowLayout required for drawing the cells
            let space = 10.0 as CGFloat

            // Set view cell size
        flowLayout.itemSize = CGSize(width: OptionCollectionViewCell.heigtSize, height: OptionCollectionViewCell.heigtSize)

            // Set left and right margins
            flowLayout.minimumInteritemSpacing = space

            // Set top and bottom margins
            flowLayout.minimumLineSpacing = space
        flowLayout.scrollDirection = .horizontal
        collectionView = UICollectionView(frame: CGRect(x: 0, y: 10, width: self.frame.size.width, height: 60.0), collectionViewLayout: flowLayout)
        collectionView.register(OptionCollectionViewCell.self, forCellWithReuseIdentifier: OptionCollectionViewCell.identifier)
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.backgroundColor = .clear
        self.addSubview(collectionView)
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            collectionView.centerYAnchor.constraint(equalTo: self.centerYAnchor),
            collectionView.leadingAnchor.constraint(equalTo: self.leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: 0),
            collectionView.heightAnchor.constraint(equalToConstant: 60)
            ])
    }
}
