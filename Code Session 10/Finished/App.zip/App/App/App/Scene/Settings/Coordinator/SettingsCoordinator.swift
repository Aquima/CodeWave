//
//  SettingsCoordinator.swift
//  App
//
//  Created by Raul on 21/12/21.
//

import UIKit

class SettingsCoordinator: Coordinator {
    var navigation: UINavigationController
    init(navigation: UINavigationController) {
        self.navigation = navigation
    }
    func start() {
        let vc = SettingsViewController.init(nibName: "SettingsViewController", bundle: Bundle.main)
        self.navigation.pushViewController(vc, animated: true)
    }
}
