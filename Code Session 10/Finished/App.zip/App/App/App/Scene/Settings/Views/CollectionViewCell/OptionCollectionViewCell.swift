//
//  OptionCollectionViewCell.swift
//  App
//
//  Created by Raul on 23/12/21.
//

import UIKit

class OptionCollectionViewCell: UICollectionViewCell {
    override init(frame: CGRect) {
        super.init(frame: .zero)
        createCircle()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    static let identifier: String = "OptionCollectionViewCell"
    static let heigtSize = 60.0
    func createCircle(){
        self.contentView.backgroundColor = .clear
        let circleView = UIView(frame: CGRect(x: 0, y: 0, width: 60, height: 60))
        circleView.layer.cornerRadius = 30.0
        circleView.layer.masksToBounds = true
        circleView.backgroundColor = .red
        self.contentView.addSubview(circleView)
        NSLayoutConstraint.activate([
            circleView.leadingAnchor.constraint(equalTo: self.contentView.leadingAnchor),
            circleView.trailingAnchor.constraint(equalTo: self.contentView.trailingAnchor, constant: 0),
            circleView.topAnchor.constraint(equalTo: self.contentView.topAnchor),
            circleView.bottomAnchor.constraint(equalTo: self.contentView.bottomAnchor)
            ])
    }
}
