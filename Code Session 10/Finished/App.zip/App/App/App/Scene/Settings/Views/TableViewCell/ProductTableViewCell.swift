//
//  ProductTableViewCell.swift
//  App
//
//  Created by Raul on 23/12/21.
//

import UIKit

class ProductTableViewCell: UITableViewCell {
    static let identifier: String = "ProductTableViewCell"
    static let heigtSize = 40.0
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func load(title:String){
        self.textLabel?.text = title
        self.textLabel?.textColor = .white
        self.contentView.backgroundColor = .red
    }
}
