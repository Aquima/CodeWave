
public class LocalAuth: NSObject {
    public func initializeAuth() {
        print("initializeAuth")
    }
}
