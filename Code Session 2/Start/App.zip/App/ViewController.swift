//
//  ViewController.swift
//  App
//
//  Created by Raul Quispe on 15/12/21.
//

import UIKit

class ViewController: UIViewController {
    var topBar: TopBarView = TopBarView()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
     
    }
    func setupUI(){
        topBar = TopBarView()
    }
}

