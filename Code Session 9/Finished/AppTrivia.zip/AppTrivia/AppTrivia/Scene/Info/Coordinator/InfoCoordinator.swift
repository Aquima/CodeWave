//
//  InfoCoordinator.swift
//  AppTrivia
//
//  Created by Raul on 22/12/21.
//

import UIKit

class InfoCoordinator: Coordinator {
    var presenter: UINavigationController
    init(_ presenter: UINavigationController) {
        self.presenter = presenter
    }
    func start() {
       
       let qvc: InfoViewController = InfoViewController.init(nibName: "InfoViewController", bundle: Bundle.main)
        self.presenter.pushViewController(qvc, animated: true)
    }
}
