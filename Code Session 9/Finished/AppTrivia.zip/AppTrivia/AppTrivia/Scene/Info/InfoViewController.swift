//
//  InfoViewController.swift
//  AppTrivia
//
//  Created by Raul on 22/12/21.
//

import UIKit

class InfoViewController: UIViewController {
    var textView: UITextView = UITextView()
    var lblTitle: UILabel = UILabel()
    var logo: UIImageView = UIImageView()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        // Do any additional setup after loading the view.
        
        //        let scrollView = UIScrollView(frame: CGRect(x: 10, y: 200, width: self.view.frame.width-20, height: self.view.frame.height-210))
        //        scrollView.showsVerticalScrollIndicator = true
        //        scrollView.contentSize = CGSize(width: self.view.frame.width-20, height: 1200)
        //
        //        self.view.addSubview(scrollView)
        //
        //        NSLayoutConstraint.activate([
        //            // Place the button at the center of its parent
        //            scrollView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 10),
        //            scrollView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -10),
        //            scrollView.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 200),
        //            scrollView.bottomAnchor.constraint(equalTo: self.view.bottomAnchor, constant: -10)
        //
        //        ])
        setupUI()
    }
    func setupUI(){
        view.addSubview(textView)
        view.addSubview(logo)
        view.addSubview(lblTitle)
        logo.translatesAutoresizingMaskIntoConstraints = false
        textView.translatesAutoresizingMaskIntoConstraints = false
        lblTitle.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            textView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 10),
            textView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -10),
            textView.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 210),
            textView.bottomAnchor.constraint(equalTo:  self.view.safeAreaLayoutGuide.bottomAnchor, constant: 0),
            ])
        NSLayoutConstraint.activate([
            lblTitle.centerXAnchor.constraint(equalTo: self.view.centerXAnchor),
            lblTitle.topAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.topAnchor, constant: 40),
            lblTitle.widthAnchor.constraint(equalToConstant: 250),
            lblTitle.heightAnchor.constraint(equalToConstant: 25)
            ])
        NSLayoutConstraint.activate([
            logo.centerXAnchor.constraint(equalTo: self.view.centerXAnchor),
            logo.topAnchor.constraint(equalTo: lblTitle.bottomAnchor, constant: 10),
            logo.widthAnchor.constraint(equalToConstant: 60),
            logo.heightAnchor.constraint(equalToConstant: 60)
            ])
       
        logo.image = UIImage.init(named: "logo")!//SwiftGen
        
        textView.backgroundColor = .clear
        let bottomSafeArea = UIView()
        bottomSafeArea.backgroundColor = .clear
        
        self.view.addSubview(bottomSafeArea)
        bottomSafeArea.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            bottomSafeArea.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 10),
            bottomSafeArea.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -10),
            bottomSafeArea.bottomAnchor.constraint(equalTo: self.view.bottomAnchor, constant: 0),
            bottomSafeArea.topAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.bottomAnchor, constant: 0)
            ])
//        view.backgroundColor = .red
        lblTitle.text = "About Alkemy Trivia"
        lblTitle.textAlignment = .center
        let content = """
            is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever \
            since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has \
            survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was\
            popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently \
                        is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever \
                        since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has \
                        survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was\
                        popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently \
                        is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever \
                        since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has \
                        survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was\
                        popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently \
                        is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever \
                        since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has \
                        survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was\
                        popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently \
                        is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever \
                        since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has \
                        survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was\
                        popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently \
                        is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever \
                        since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has \
                        survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was\
                        popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently \
                        is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever \
                        since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has \
                        survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was\
                        popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently \
            with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum
            """
        textView.font = UIFont(name: "Helvetica", size: 15)!
        textView.text = content
        textView.isScrollEnabled = true
        textView.isSelectable = false
        
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
