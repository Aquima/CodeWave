//
//  LogInCoordinator.swift
//  AppTrivia
//
//  Created by Raul on 22/12/21.
//

import UIKit

class LogInCoordinator: Coordinator {
    var presenter: UINavigationController
    init(_ presenter: UINavigationController) {
        self.presenter = presenter
    }
    func start() {
        let storyboard = UIStoryboard.init(name: "Main", bundle: Bundle.main)
        guard let lvc: LoginViewController = storyboard.instantiateViewController(withIdentifier: "loginVC") as? LoginViewController else {
            return
        }
        self.presenter.pushViewController(lvc, animated: true)
    }
}
