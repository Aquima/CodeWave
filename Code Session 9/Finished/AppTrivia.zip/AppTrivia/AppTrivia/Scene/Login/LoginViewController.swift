//
//  ViewController.swift
//  AppTrivia
//
//  Created by Raul on 22/12/21.
//

import UIKit

class LoginViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func tapLogin(){
        let questionCoordinator = QuestionCoordinator(self.navigationController!)
        questionCoordinator.start()
//        let isSelected = true
//        if isSelected {
//
//            self.performSegue(withIdentifier: "goToBlankview", sender: nil)
//        } else {
//            self.performSegue(withIdentifier: "questionVCSegue", sender: nil)
//        }
//        let resultview = ResultViewController.init(nibName: "ResultViewController", bundle: Bundle.main)
//        self.present(resultview, animated: true, completion: nil)
//        let storyboard = UIStoryboard.init(name: "Main", bundle: Bundle.main)
//        guard let qvc: QuestionViewController = storyboard.instantiateViewController(withIdentifier: "questionVC") as? QuestionViewController else {
//           return
//        }
//        qvc.modalPresentationStyle = .fullScreen
//        self.present(qvc, animated: false,
//                     completion: {
//            print("Load QuestionView Completed")
//
//        })
    }
    @IBAction func goToInfo(){
        let infoCoordinator = InfoCoordinator(self.navigationController!)
        infoCoordinator.start()
    }
    

}

