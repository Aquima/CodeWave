//
//  Question.swift
//  AppTrivia
//
//  Created by Raul on 22/12/21.
//

import UIKit

struct Question {
    let question: String
    let answer:Bool
}

