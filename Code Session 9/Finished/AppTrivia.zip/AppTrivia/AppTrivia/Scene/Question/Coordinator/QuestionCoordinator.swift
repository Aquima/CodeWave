//
//  QuestionCoordinator.swift
//  AppTrivia
//
//  Created by Raul on 22/12/21.
//

import UIKit

class QuestionCoordinator: Coordinator {
    var presenter: UINavigationController
    init(_ presenter: UINavigationController) {
        self.presenter = presenter
    }
    func start() {
        let storyboard = UIStoryboard.init(name: "Main", bundle: Bundle.main)
        guard let qvc: QuestionViewController = storyboard.instantiateViewController(withIdentifier: "questionVC") as? QuestionViewController else {
            return
        }
        self.presenter.pushViewController(qvc, animated: true)
    }
}
