//
//  QuestionViewController.swift
//  AppTrivia
//
//  Created by Raul on 22/12/21.
//

import UIKit

class QuestionViewController: UIViewController {
    @IBOutlet weak var closeOption: UIButton!
    @IBOutlet weak var checkOption: UIButton!
    @IBOutlet weak var questionLabel: UILabel!
    
    private let questions = Contenido.shared.obtenerPreguntas()
    private var currentQuestionIndex = 0

    private var attemptsIndex: Set<Int> = Set<Int>()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        setupUI()
        drawQuestion()
    }
    func drawQuestion(){
        let randomInt = Int.random(in: 0..<questions.count)
        
        if !attemptsIndex.contains(randomInt) {
            let quest = questions[randomInt]
            questionLabel.text = quest.question
            attemptsIndex.insert(randomInt)
        }else{
            if attemptsIndex.count != 11 {
                drawQuestion()
            }
        }
    }
    func setupUI(){
        checkOption.layer.cornerRadius = 40
        checkOption.layer.masksToBounds = true
        
        closeOption.layer.cornerRadius = 40
        closeOption.layer.masksToBounds = true
        
        checkOption.addTarget(self, action: #selector(nextQuestion(_:)), for: .touchUpInside)
//        let viewContent = UIView.init(frame: CGRect(x: 100, y: 100, width: 200, height: 50))
//        viewContent.backgroundColor = .blue
//        viewContent.layer.masksToBounds = true
//        self.view.addSubview(viewContent)
//
//        let redView = UIView.init(frame: CGRect(x: 50, y: 10, width: 200, height: 50))
//        redView.backgroundColor = .red
//        viewContent.addSubview(redView)
    }
    @objc func nextQuestion(_ sender:UIButton ){
        drawQuestion()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
