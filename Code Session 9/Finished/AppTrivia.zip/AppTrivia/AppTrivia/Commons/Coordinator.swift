//
//  Coordinator.swift
//  AppTrivia
//
//  Created by Raul on 22/12/21.
//

import UIKit

protocol Coordinator {
    var presenter: UINavigationController { get }
    func start()
}
