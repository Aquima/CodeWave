//
//  AppDelegate.swift
//  AppTrivia
//
//  Created by Raul on 22/12/21.
//

import UIKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate {
    var windows: UIWindow!
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        let navigation = UINavigationController()
        windows = UIWindow(frame: UIScreen.main.bounds)
        let loginCoordinator = LogInCoordinator.init(navigation)
        loginCoordinator.start()
        windows.rootViewController = navigation
        windows.makeKeyAndVisible()
//        [login,question,...]
        return true
    }
}

