//
//  HomeBankingViewController.swift
//  App
//
//  Created by Raul on 16/12/21.
//

import UIKit

class HomeBankingViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let account = Account()
        guard let showBalanceAccountView = self.view as? ShowBalanceAccountView else {
            return
        }
        showBalanceAccountView.showBalance(account)
        let currentUser = User(name: "Raul")
//        showBalanceAccountView.showUserName(currentUser)
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
