//
//  Account.swift
//  App
//
//  Created by Raul on 16/12/21.
//

import Foundation

class Account: NSObject {
    private(set) var balance: Double = 0.0
    private(set) var currency: String = "$"
    func increment(_ amount: Double,currency: String) {
        self.currency = currency
        balance = balance + amount
    }
    func currentBalance()-> Double {
        return balance
    }
    func change(currency typeMoney: String)-> String {
        self.currency = typeMoney
        return self.currency
    }
    func withdraw(_ amount: Double)throws -> ErrorType? {
        if self.balance < amount {
            return .notBalance
        }
        return nil
    }
}
enum ErrorType {
    case notBalance
}
