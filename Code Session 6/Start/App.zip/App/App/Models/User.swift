//
//  User.swift
//  App
//
//  Created by Raul on 16/12/21.
//

import Foundation
import UIKit

struct User {
    private var name: String
    var age: Int
    var money: Double
    var address: String
    init(name: String,
         age: Int = 0,
         money: Double = 0.0,
         address: String = "") {
        self.name = name
        self.age = age
        self.money = money
        self.address = address
    }
}
