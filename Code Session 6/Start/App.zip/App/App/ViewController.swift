//
//  ViewController.swift
//  App
//
//  Created by Raul Quispe on 15/12/21.
//

import UIKit
class ViewController: UIViewController {
    @IBOutlet weak var topContraintIcon: NSLayoutConstraint!
    @IBOutlet weak var button: UIButton!
    @IBOutlet weak var lblDisplay: UILabel!
    var topBar: TopBarView = TopBarView()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.button.addTarget(self,
                              action: #selector(toAction(_:)),
                              for: .touchUpInside)
    }
    func setupUI(){
        topBar = TopBarView()
    }
    func useforIn() {
        for element in 0..<3 {
            print(element)
        }
        let primary = 4
        let secondary = 5
        if primary == secondary {
            print("equal")
        } else if primary < secondary {
            print("minor")
        }
        let entero: Int? = primary>3 ? 7 : nil
        print(entero!)
        let state = self.button.state
        switch state {
        case .normal:
            print("Normal")
            break
        case .focused:
            print("Focused")
            break
        case .highlighted:
            print("highlighted")
            break
        default:
            print("Default")
        }
        guard let existeEntero = entero else {
            return
        }
        print(existeEntero)
    }
    func useCatching(){


        let jsonText = "{\"first_name\"\"Sergey\"}"
        var dictonary: Dictionary<String,String>?
               
               if let data = jsonText.data(using: String.Encoding.utf8) {
                   
                   do {
                       dictonary = try JSONSerialization.jsonObject(with: data, options: []) as? [String:String]
                   
                       if let myDictionary = dictonary
                       {
                            print(" First name is: \(myDictionary["first_name"]!)")
                       }
                   } catch let error as NSError {
                       print(error)
                   }
               }
        
//        do {
//            let jsonData = try JSONSerialization.data(withJSONObject: dic, options: .prettyPrinted)
//            // here "jsonData" is the dictionary encoded in JSON data
//
//            let decoded = try JSONSerialization.jsonObject(with: jsonData, options: [])
//            // here "decoded" is of type `Any`, decoded from JSON data
//
//            // you can now cast it with the right type
//            if let dictFromJSON = decoded as? [String:String] {
//                // use dictFromJSON
//            }
//        } catch {
//            print(error.localizedDescription)
//        }
    }
    //Set
    func useSet(){
        var conjuntoA = Set<Int>()
        conjuntoA = [1,2,2,3]
        print(conjuntoA)
        var conjuntoB = Set<Int>()
        conjuntoB = [3,4,5]
        print(conjuntoB)
        let union = conjuntoA.union(conjuntoB)
        let intersection = conjuntoA.intersection(conjuntoB)
        let diferenciaAB = conjuntoA.symmetricDifference(conjuntoB)
    }
    //Arreglos
    func useArray() {
        let integers: [Int] = [1, 2, 3, 3, 3]
        print(integers[0])
        
        var doubles: [Double] = []
        doubles.append(5.5)
        doubles.append(5.7)
        //        doubles.remove(at: 0)
        //        doubles.removeAll()
        doubles[0] = 5.6
        print(doubles.first)
        print(doubles.contains(5.6))
        print(doubles.last)
        print(integers[0])
        
        var anyObjects: [Any] = [1,5,"Hola"]
        anyObjects.append(1.5)
    }
    //Tuplas
    typealias mytupla = (String, Int, Double)
    func useTuplas()-> mytupla {
        let userData = ("Luisa",22,0.2)
        print(userData.0)
        print(userData.1)
        print(userData.2)
        
        return userData
    }
    
    //Dictionary
    //key = value
    func useDictionary() -> Int {
        //Automatic Reference Counting
        var dict: [String:Int] = [:]
        dict["primary"] = 4
        
        let dictionary: [String:Int] = ["secondary": 1,
                                        "tertiary": 3]
        print(dictionary["tertiary"]!)
        return dict["primary"]!
    }
    @objc func toAction(_ sender: Any) {
        
        //        if let btn = sender as? UIButton {
        //            btn.setTitleColor(.white, for: .normal)
        //            btn.setTitle("change", for: .normal)
        //        }
        //        useArray()
        //        lblDisplay.text = "\(useDictionary())"
        //        lblDisplay.textColor = UIColor.black
        //        lblDisplay.font = UIFont(name: "Helvetica", size: 10)
        //
        //        topContraintIcon.constant = 250
        useCatching()
    }
}


