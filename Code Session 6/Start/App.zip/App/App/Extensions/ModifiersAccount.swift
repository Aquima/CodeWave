//
//  ModifiersAccount.swift
//  App
//
//  Created by Raul on 16/12/21.
//

import Foundation

extension Account {
    func currentMoney() -> String {
        return "\(String(describing: self.currency)) \(self.balance)"
    }
}
