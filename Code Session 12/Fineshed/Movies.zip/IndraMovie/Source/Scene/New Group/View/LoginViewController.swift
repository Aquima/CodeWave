//
//  LoginViewController.swift
//  IndraMovie
//
//  Created by Raul on 29/12/21.
//  Copyright © 2021 Raul Quispe. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController,
                            BindableType, UIGestureRecognizerDelegate {
    var viewModel: LoginViewModel!

    @IBOutlet weak var usernameField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var button: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        let piloto: Piloto = Piloto()
//        let aeroplane = Aeroplane(piloto: piloto)
//        piloto.aeroplane = aeroplane
//
//        piloto.aeroplane = nil
        button.isEnabled = false
        button.addTarget(self, action: #selector(loginProcess(_:)), for: .touchUpInside)
        usernameField.becomeFirstResponder()//leavanta el teclado
        //mail@dominio.com
        usernameField.clearButtonMode = .always
        usernameField.placeholder = "Ingresa Email"
        usernameField.delegate = self
        usernameField.returnKeyType = .next
        usernameField.keyboardType = .emailAddress
        usernameField.tag = 0
        
        passwordField.isSecureTextEntry = true
        passwordField.placeholder = "Contraseña"
        passwordField.keyboardType = .numberPad
        passwordField.tag = 1
        
        passwordField.addTarget(self, action: #selector(changeText(textfield:)), for: .editingChanged)
        setupGesture()
    }
    func setupGesture(){
        let shortPressGesture = UITapGestureRecognizer(target: self, action: #selector(quitKeyboard(_:)))
        shortPressGesture.delegate = self
        self.view.addGestureRecognizer(shortPressGesture)
    }
    @objc func loginProcess(_ sender: UIButton){
        print("ya me tengo que ir a cenar")
    }
    @objc func changeText(textfield: UITextField) {
        if textfield.tag  == 1 && textfield.text?.count == 3 {
            passwordField.resignFirstResponder()
            button.isEnabled = true
        }
    }
    @objc func quitKeyboard(_ gesture: UITapGestureRecognizer){
        usernameField.resignFirstResponder()
        passwordField.resignFirstResponder()
    }
    func bindViewModel() {
        
    }
}
extension LoginViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if !textField.text!.isEmpty && textField.text!.isValidEmail {
            usernameField.resignFirstResponder()
            passwordField.becomeFirstResponder()
        }
        return true
    }
}
extension String {
    var isValidEmail: Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        
        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: self)
    }
}
//// Clase Aeroplano (name, modelo, Piloto)
////       Piloto (name,age, Aeroplano)
//// weak o strong ARC(0)
//// Java Garbage Collector
//class Aeroplane {
//    var name: String = ""
//    var modelo: String = ""
//    var piloto: Piloto!
//    init(piloto: Piloto){
//        self.piloto = piloto
//    }
//}
//class Piloto {
//    var name:String = ""
//    var age: Int = 9
//    weak var aeroplane: Aeroplane!
//    init(){
//
//    }
//}
