//
//  LoginViewModel.swift
//  IndraMovie
//
//  Created by Raul on 29/12/21.
//  Copyright © 2021 Raul Quispe. All rights reserved.
//

import Foundation

struct LoginViewModel {
    let sceneCoordinator: CoordinatorView
    init(coordinator:CoordinatorView) {
        self.sceneCoordinator = coordinator
    }
}
