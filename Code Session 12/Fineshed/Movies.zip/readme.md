# IndraMovie

Kata Mobile iOS

## Description

Tech Review for Indra

## Getting Started
 ```
 user: jordyaguilar
 pass: github2022
```
### Dependencies

pod 'RxSwift', '5.0.0' 
  pod 'RxCocoa', '5.0.0'
  pod 'RxGesture'
  pod 'RxDataSources', '4.0.1'
  pod 'TraktKit', '1.0.8'
  pod 'SDWebImage', '5.0.6'
  pod 'Shimmer', '1.0.2'

### Installing

* execute
```
pod install
```
